# BSDS-V53
Python Brawl Stars server emulator for version 53

## How to play: ##

### Server ###
I use a zip server from BSDS that [LkPrtctrd](https://github.com/LkPrtctrd) modified which was made by [Сrazor](https://github.com/CrazorTheCat) and [risporse](https://github.com/risporce)

1: Download the server and extract it: 

2: Open terminal on your computer and go to server directory.

3: Type python Main.py and it's done, follow client instructions.

### Android Client ###
1: Download the APK here: soon

2: Change redirectHost (and redirectPort if you need it) in the frida config (lib/armeabi-v7a/libprojectbsds.c.so)

3: Enjoy playing BSDS-V53!

## Screenshots ##
![BSDS-V53]()