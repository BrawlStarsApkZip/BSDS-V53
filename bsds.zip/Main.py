serverAddress = ("0.0.0.0", 9339)

import socket
from Heart.Connection import Connection
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, True)
server.bind(serverAddress)
print("Listening for new connection...")
while True:
    server.listen()
    socket, address = server.accept()
    print("New connection with address", address[0], "on port", address[1])
    Connection(socket, address).start()